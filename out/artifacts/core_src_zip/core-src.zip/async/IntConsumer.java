package async;


public interface IntConsumer {

    void accept(int data);
//
//    default void onCancelled(int data) {}
}
