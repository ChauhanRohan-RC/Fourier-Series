package async;

public interface ThrowableRunnable {
    void run() throws Throwable;
}
