package async;

public interface LongConsumer {
    void accept(long data);
}
