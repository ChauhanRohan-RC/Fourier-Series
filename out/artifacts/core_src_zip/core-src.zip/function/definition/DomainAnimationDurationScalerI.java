package function.definition;

public interface DomainAnimationDurationScalerI {

    float getDomainAnimationDurationScale();

    DomainAnimationDurationScalerI setDomainAnimationDurationScale(float animationDurationScale);
}
