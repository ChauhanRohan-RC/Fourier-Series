package util.main;

import function.ComplexDomainFunctionWrapper;
import function.definition.ComplexFunctionI;
import function.definition.ComplexDomainFunctionI;
import function.definition.FrequencySupportProviderI;
import misc.MathUtil;
import models.ComplexBuilder;
import org.apache.commons.math3.complex.Complex;
import org.jetbrains.annotations.NotNull;

import java.util.function.IntFunction;

public class ComplexUtil {

    public static final String TAG = "ComplexUtil";

    public static final int SIMPSON_13_N_MIN = 2;       // Must be even
    public static final int SIMPSON_13_N_DEFAULT = 100;

    public static final int SIMPSON_38_N_MIN = 3;       // must be multiple of 3
    public static final int SIMPSON_38_N_DEFAULT = 51;

    /* Fourier Transform */
    /**
     * Defines Fourier Transform integrand exp term sign <br>
     * <strong>
     *     Must be Complimentary to Fourier Series rotor direction
     * </strong>
     * */
    public static final boolean FOURIER_TRANSFORM_CLOCKWISE = true;

    /**
     * Defines whether {@link MathUtil#TWO_PI} should be used in Fourier Transform integrand exp term<br>
     * <br>
     * If it is used, then the frequencies decomposed by FT algorithm will be temporal<br>
     * otherwise, angular
     * */
    public static final boolean FOURIER_TRANSFORM_USE_TWO_PI = true;

    public static final int FOURIER_TRANSFORM_SIMPSON_13_N_MIN = SIMPSON_13_N_MIN;
    public static final int FOURIER_TRANSFORM_SIMPSON_13_N_DEFAULT = 100000;

    private static int sFtSimpson13NCurrentDefault = FOURIER_TRANSFORM_SIMPSON_13_N_DEFAULT;

    public static boolean setFourierTransformSimpson13NCurrentDefault(int ftSimpson13NCurrentDefault) {
        if (ftSimpson13NCurrentDefault < FOURIER_TRANSFORM_SIMPSON_13_N_MIN)
            return false;

        sFtSimpson13NCurrentDefault = ftSimpson13NCurrentDefault;
        return true;
    }

    public static int getFourierTransformSimpson13NCurrentDefault() {
        return sFtSimpson13NCurrentDefault;
    }


    private ComplexUtil() {
    }

    @NotNull
    public static Complex polarExact(double r, double rad) {
        if (Double.isNaN(r) || Double.isNaN(rad)) {
            return Complex.NaN;
        }

        return new Complex(r * MathUtil.cosexact(rad), r * MathUtil.sinexact(rad));
    }

    @NotNull
    public static Complex polarFast(double r, double rad) {
        return new Complex(r * MathUtil.cosfast(rad), r * MathUtil.sinfast(rad));
    }

    @NotNull
    public static Complex polarUnitExact(double rad) {
        if (Double.isNaN(rad)) {
            return Complex.NaN;
        }

        return new Complex(MathUtil.cosexact(rad), MathUtil.sinexact(rad));
    }

    @NotNull
    public static Complex polarUnitFast(double rad) {
        return new Complex(MathUtil.cosfast(rad), MathUtil.sinfast(rad));
    }



    @NotNull
    public static Complex lerp(@NotNull Complex p0, @NotNull Complex p1, float t) {
        final double _t = 1 - t;
        return new Complex((_t * p0.getReal()) + (t * p1.getReal()), (_t * p0.getImaginary()) + (t * p1.getImaginary()));
    }


    @NotNull
    public static ComplexDomainFunctionI getBaseFunction(@NotNull ComplexDomainFunctionI function) {
        while (function instanceof ComplexDomainFunctionWrapper wrapper) {
            function = wrapper.getBaseFunction();
        }

        return function;
    }




    public static int getDirection(boolean clockwise) {
        return clockwise? 1: -1;
    }


    /**
     * Integrates a complex function using Simpson 1/3 rule
     * In most cases, it is more accurate than Simpson 3/8 and far more than Trapezoid
     *
     * It uses a quadratic (degree 2) interpolation
     *
     * @param f function to integrate
     * @param a lower limit
     * @param b upper limit
     * @param n number of intervals integration range will be divided in, must be EVEN (0 or -ve to use default)
     *
     * @see #simpson38(ComplexFunctionI, double, double, int)
     * */
    @NotNull
    public static Complex simpson13(final @NotNull ComplexFunctionI f, final double a, final double b, int n) {
        final double range = b - a;
        if (range == 0)
            return Complex.ZERO;        // todo

        // N
        if (n <= 0) {
            n = SIMPSON_13_N_DEFAULT;
        } else if (n < SIMPSON_13_N_MIN) {
            n = SIMPSON_13_N_MIN;
        }

        if ((n % 2) != 0) {
            n++;   /* must be even */
        }

        // main
        final double h = range / n;
        final ComplexBuilder s = new ComplexBuilder();

        // 1. End Points
        s.add(f.compute(a));
        s.add(f.compute(b));

        // 2. Odd Points
        for (int i=1; i < n; i+=2) {
            s.add(f.compute(a + (i * h)), 4);
        }

        // 3. Even Points
        for (int i=2; i < n; i+=2) {
            s.add(f.compute(a + (i * h)), 2);
        }

        return s.mult(h / 3).toComplex();
    }

    @NotNull
    public static Complex simpson13(final @NotNull ComplexFunctionI f, final double a, final double b) {
        return simpson13(f, a, b, 0);
    }


    /**
     * Integrates a complex function using Simpson 3/8 rule
     * In most cases, it is less accurate than Simpson 1/3 but can be twice as accurate in some cases
     * <p>
     * It uses a cubic (degree 3) interpolation
     *
     * @param f function to integrate
     * @param a lower limit
     * @param b upper limit
     * @param n number of intervals integration range will be divided in, must be MULTIPLE OF 3 (0 or -ve to use default)
     *
     * @see #simpson13(ComplexFunctionI, double, double, int)
     * */
    @NotNull
    public static Complex simpson38(final @NotNull ComplexFunctionI f, final double a, final double b, int n) {
        // N
        if (n <= 0) {
            n = SIMPSON_38_N_DEFAULT;
        } else if (n < SIMPSON_38_N_MIN) {
            n = SIMPSON_38_N_MIN;
        }

        int r = n % 3;
        if (r != 0) {
            n += (3 - r);           // must be a multiple of 3
        }

        // main.Main
        final double h = (b - a) / n;
        final ComplexBuilder s = new ComplexBuilder();

        // 1. End Points
        s.add(f.compute(a));
        s.add(f.compute(b));

        // 2. Mid Points
        double x = a;
        for (int i=1; i < n; i++) {
            x += h;
            s.add(f.compute(x), (i % 3) != 0? 3: 2);
        }

        return s.mult(h * 0.375 /* 3/8 */).toComplex();
    }

    @NotNull
    public static Complex simpson38(final @NotNull ComplexFunctionI f, final double a, final double b) {
        return simpson38(f, a, b, 0);
    }



    /* ........................................ Fourier Transform ................................ */

    @NotNull
    public static ComplexBuilder complexExpExact(double x) {
        return new ComplexBuilder(MathUtil.cosexact(x), MathUtil.sinexact(x));
    }

    @NotNull
    public static ComplexBuilder complexExpFast(double x) {
        return new ComplexBuilder(MathUtil.cosfast(x), MathUtil.sinfast(x));
    }

    /**
     * gets constant part of power of Fourier Transform exponential term
     * <br>
     * Typically, the exponential term is <code>e<sup>-2.pi.f.t</sup></code>
     * then, constant part of power (independent of t) is -2.pi.f
     *
     * @param direction directional factor, usually given by {@link #getDirection(boolean)}
     * @param frequency the winding frequency
     * @return constant part of power of Fourier Transform exponential term
     * */
    public static double getFourierExpTermPowerCoefficient(int direction, double frequency) {
        double pre = direction * frequency;
        if (FOURIER_TRANSFORM_USE_TWO_PI) {
            pre *= MathUtil.TWO_PI;
        }

        return pre;
    }

    @NotNull
    public static ComplexFunctionI fourierTransformIntegrand(@NotNull ComplexFunctionI f, double frequency, boolean clockwise) {
//        if (f instanceof FrequencySupportProviderI fsp && !fsp.isFrequencySupported(frequency)) {
//            return ComplexFunctionI.ZERO;
//        }

        final double pre = getFourierExpTermPowerCoefficient(getDirection(clockwise), frequency);
        return t -> complexExpFast(pre * t).mult(f.compute(t)).toComplex();
    }

    @NotNull
    public static ComplexFunctionI fourierTransformIntegrand(@NotNull ComplexFunctionI f, double frequency) {
        return fourierTransformIntegrand(f, frequency, FOURIER_TRANSFORM_CLOCKWISE);
    }


    @NotNull
    public static ComplexDomainFunctionI fourierTransformIntegrand(@NotNull ComplexDomainFunctionI f, double frequency, boolean clockwise) {
        final ComplexFunctionI ft = fourierTransformIntegrand((ComplexFunctionI) f, frequency, clockwise);
        return new ComplexDomainFunctionWrapper(f) {
            @Override
            public @NotNull Complex compute(double input) {
                return ft.compute(input);
            }
        };
    }

    @NotNull
    public static ComplexDomainFunctionI fourierTransformIntegrand(@NotNull ComplexDomainFunctionI f, double frequency) {
        return fourierTransformIntegrand(f, frequency, FOURIER_TRANSFORM_CLOCKWISE);
    }




    /**
     * Core method where integration happens
     *
     * @return fourier transform value of a function for a certain "winding" frequency
     *
     * TODO: implement FASt FOURIER TRANSFORM
     * */
    @NotNull
    public static Complex fourierTransform(@NotNull ComplexFunctionI f, double frequency, double a, double b, int n) {
        // If frequency is not supported
        if (f instanceof FrequencySupportProviderI fsp && !fsp.isFrequencySupported(frequency)) {
            return Complex.ZERO;
        }

        return simpson13(fourierTransformIntegrand(f, frequency), a, b, n > 0? n: getFourierTransformSimpson13NCurrentDefault());
    }

    @NotNull
    public static Complex fourierTransform(@NotNull ComplexFunctionI f, double frequency, double a, double b) {
        return fourierTransform(f, frequency, a, b, -1);
    }

    @NotNull
    public static Complex fourierTransform(@NotNull ComplexDomainFunctionI f, double frequency, double a, double b) {
        return fourierTransform(f, frequency, a, b, f.getNumericalIntegrationIntervalCount());
    }

    @NotNull
    public static Complex fourierTransform(@NotNull ComplexDomainFunctionI f, double frequency, int n) {
        return fourierTransform(f, frequency, f.getDomainStart(), f.getDomainEnd(), n);
    }

    @NotNull
    public static Complex fourierTransform(@NotNull ComplexDomainFunctionI f, double frequency) {
        return fourierTransform(f, frequency, f.getNumericalIntegrationIntervalCount());
    }


    /* ................................. Fourier Series ................................... */

    // Must be complimentary of coefficient direction
    public static int getFourierSeriesRotorTipDirection() {
        return getDirection(!FOURIER_TRANSFORM_CLOCKWISE);
    }


    /**
     * Fourier Transform output -> Fourier Series coefficient
     * */
    @NotNull
    public static Complex ftToFsCoefficient(@NotNull Complex complex, double domainRange) {
        return complex.divide(domainRange);
    }

    /**
     * Fourier Series Coefficient -> Fourier Transform output
     * */
    @NotNull
    public static Complex fsCoefficientToFt(@NotNull Complex complex, double domainRange) {
        return complex.multiply(domainRange);
    }

    @NotNull
    public static Complex fourierSeriesCoefficient(@NotNull ComplexFunctionI f, double frequency, double a, double b, int n) {
        return ftToFsCoefficient(fourierTransform(f, frequency, a, b, n), b - a);
    }

    @NotNull
    public static Complex fourierSeriesCoefficient(@NotNull ComplexFunctionI f, double frequency, double a, double b) {
        return fourierSeriesCoefficient(f, frequency, a, b, -1);
    }

    @NotNull
    public static Complex fourierSeriesCoefficient(@NotNull ComplexDomainFunctionI f, double frequency, double a, double b) {
        return fourierSeriesCoefficient(f, frequency, a, b, f.getNumericalIntegrationIntervalCount());
    }

    @NotNull
    public static Complex fourierSeriesCoefficient(@NotNull ComplexDomainFunctionI f, double frequency, int n) {
        return fourierSeriesCoefficient(f, frequency, f.getDomainStart(), f.getDomainEnd(), n);
    }

    @NotNull
    public static Complex fourierSeriesCoefficient(@NotNull ComplexDomainFunctionI f, double frequency) {
        return fourierSeriesCoefficient(f, frequency, f.getNumericalIntegrationIntervalCount());
    }
    
    
    /* TODO: FFT Test (not that fast....yet) */

    private static final int FFT_DEFAULT_NP_HINT = FOURIER_TRANSFORM_SIMPSON_13_N_DEFAULT;
    private static final int FFT_N_MIN = 4;     // power of 2

    @NotNull
    public static Complex fft(@NotNull ComplexFunctionI func, double a, double b, double fq, int np_hint) {
        if (func instanceof FrequencySupportProviderI fsp && !fsp.isFrequencySupported(fq)) {
            return Complex.ZERO;
        }

        final double range = b - a;
        if (range == 0)
            return Complex.ZERO;

        if (fq == 0)
            return simpson13(func, a, b, np_hint);

        if (np_hint <= 0) {
            np_hint = FFT_DEFAULT_NP_HINT;
        } else if (np_hint < FFT_N_MIN) {
            np_hint = FFT_N_MIN;
        }

        final double c = fq * range;            // can be -ve
        final double absC = Math.abs(c);
        if (absC < 1 || absC > np_hint)
            return simpson13(fourierTransformIntegrand(func, fq), a, b, np_hint);

        final double n_hint_d = np_hint / absC;
        int n_hint = MathUtil.highestPowOf2((int) n_hint_d);
        if (n_hint < FFT_N_MIN) {
            n_hint = FFT_N_MIN;              // N_MIN
        }

        final int n = n_hint;

        final double np_d = absC * n;
        final double h = range / np_d;

        int np_int = (int) np_d;      // >= N_MIN
        if (np_int % 2 != 0) {
            np_int--;           // must be even
        }

        // building cache
        final Complex[] cache = new Complex[n];
        cache[0] = Complex.ONE;
        cache[n / 4] = Complex.I;
        cache[n / 2] = Complex.ONE.negate();

        final double ftPre = getDirection(FOURIER_TRANSFORM_CLOCKWISE) * MathUtil.TWO_PI;
        final double pre = ftPre * MathUtil.signum(c);

        for (int i=1; i < n / 2; i++) {
            Complex val = cache[i];
            if (val == null) {
                val = complexExpFast((pre * i) / n).toComplex();
                cache[i] = val;
            }

            cache[i + (n / 2)] = val.negate();
        }


        final ComplexBuilder constant = complexExpFast(ftPre * fq * a);
//        if (Complex.ZERO.equals(constant))
//            return Complex.ZERO;

        final IntFunction<ComplexBuilder> donor = i -> new ComplexBuilder(func.compute(a + (i * h))).mult(cache[i % n]);

        // simpson 13 over [a, a + np_int * h]
        final ComplexBuilder sum = new ComplexBuilder();

        // end points
        sum.add(donor.apply(0)).add(donor.apply(np_int));

        // 2. Odd Points
        for (int i=1; i < np_int; i+=2) {
            sum.add(donor.apply(i), 4);
        }

        // 3. Even Points
        for (int i=2; i < np_int; i+=2) {
            sum.add(donor.apply(i), 2);
        }

        // core result
        sum.mult(constant).mult(h / 3);

        // Left part [a + np_int * h, b)
        final double bp = a + (np_int * h);
        if (bp < b) {
            final Complex left_result = simpson13(fourierTransformIntegrand(func, fq), bp, b, SIMPSON_13_N_MIN);
            sum.add(left_result);
        }

        return sum.toComplex();
    }

    @NotNull
    public static Complex fft(@NotNull ComplexDomainFunctionI func, double fq) {
        return fft(func, func.getDomainStart(), func.getDomainEnd(), fq, -1);
    }

}
